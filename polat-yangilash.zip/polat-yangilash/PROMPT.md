# 0-QADAM — Tayyorgarlik (buni o'zing qil)
- Bu fayl `polat-yangilash.zip` arxivi ichida keldi. Arxiv polat loyihasi ildizida ochilgan bo'lishi kerak (ichida `polat-yangilash/` papkasi bo'ladi). Ochilmagan bo'lsa: `unzip -o polat-yangilash.zip`.
- Loyiha ildizini aniqla (u yerda `package.json`, `server/`, `public/landing/menu.html`, `CLAUDE.md` bor). Topolmasang, to'xta va mendan so'ra.
- `polat-yangilash/_mockups/ziyo-buyurtma-maket.html` ni loyiha ildizidagi `_mockups/` papkasiga ko'chir (papka yo'q bo'lsa yarat). Bu fayl faqat namuna, sayt uni ishlatmaydi.
- Ishni boshlashdan oldin `git status` ni tekshir (agar git bo'lsa) va menga qaysi fayllarni o'zgartirmoqchi ekaningni qisqa reja qilib yoz, keyin darhol ishni davom ettir.

Sen Po'lat / Ziyo Famliy loyihasida ishlayapsan (Node.js + Express + SQLite, PM2'da "polat" nomi bilan ishlab turgan JONLI sayt). Avval loyiha ildizidagi CLAUDE.md va OXIRGI-ISH.md fayllarini o'qib chiq.

## Vazifa
Mijozlar menyusi sahifasidagi (public/landing/menu.html + menu-v2.css + menu-v2.js) savat va buyurtma berish qismini yangi maket asosida qayta dizayn qil. Maket fayli: `_mockups/ziyo-buyurtma-maket.html` (men uni shu papkaga yukladim). Maketni brauzerda ochib (Playwright) ko'rib chiq va uni NAMUNA sifatida ishlat. Maketdagi menyu ma'lumotlari va rasmlar ichiga joylab qo'yilgan (base64). Ularni ko'chirma: haqiqiy sahifa avvalgidek `GET ../api/public/menu` dan o'qisin.

## Maketdan olinadigan narsalar
1. Savat/checkout ko'rinishi. Kompyuter va planshetda ikki ustun: chapda savat va forma, o'ngda sticky "Hisob" kartasi va "Buyurtma berish" tugmasi. Telefonda bitta ustun va pastda qotib turadigan "Buyurtma berish" paneli.
2. "Yetkazib berish / Olib ketish" tanlovi ikkita katta kartochka ko'rinishida. Olib ketishda restoran manzili qutisi chiqadi.
3. Hisob kartasi: "Taomlar", "Yetkazib berish — Operator aytadi" (olib ketishda "Bepul"), "Jami". Tagida "To'lov: naqd yoki karta — buyurtmani qabul qilganda".
4. Buyurtma muvaffaqiyatli yuborilgandan keyingi ekran: buyurtma raqami (serverdan qaytgan haqiqiy raqam), tarkib, jami summa va "operator qo'ng'iroq qiladi" matni.
5. Menyu kartochkalari, chiplar, qidiruv va "Savatni ko'rish" paneli saytda allaqachon bor. Ularni faqat maketdagi ko'rinishga yaqinlashtir, mantiqini buzma.

## QAT'IY QOIDALAR (ma'lumotlarni buzmaslik uchun)
- Ishni boshlashdan OLDIN zaxira nusxa ol: `data/polat.db` (WAL bilan birga, sqlite `.backup` buyrug'i orqali), hamda o'zgartiradigan har bir faylning `.bak-YYYYMMDD` nusxasi.
- `.env`, `server/qz-keys/`, `data/` papkasiga, `server/schema.sql` ga va `server/db.js` dagi migratsiyalarga TEGMA.
- Bu bosqichda backend'ni (server/ papkasini) O'ZGARTIRMA. API o'zgarishsiz qoladi: `POST ../api/public/orders` avvalgi maydonlar bilan yuboriladi (full_name, phone, fulfillment, address, location lat/lng, note, items, honeypot "website"). Narxni server hisoblaydi.
- Mavjud funksiyalar saqlansin: localStorage savati, variantlar ("tur" tugmalari), GPS "Lokatsiyamni yuborish", maydon ostidagi xato matnlari, honeypot, rate-limit xabarlari, avtomatik light/dark rejim.
- Maketdagi promokod, chegirma, "Olib ketish kodi", "Vaqtini tanlash" va "Buyurtma holati" sahifasini QO'SHMA. Ularning backend'i yo'q (alohida 2-bosqich).
- `table-menu.html`, `menu.css`, `menu.js` (QR-menyu) ga TEGMA.
- Faqat statik fayllar o'zgaradi, shuning uchun `pm2 restart` shart emas.

## Tekshiruv (majburiy)
1. Playwright bilan 360, 390, 768, 1024, 1280 va 1920px kengliklarda tekshir: gorizontal scroll bo'lmasin, konsolda xato chiqmasin.
2. To'liq oqimni sina: menyudan qo'shish, variant tanlash, savatda +/−, yetkazib berish va olib ketish, xato matnlari (bo'sh ism, 9 xonadan kam telefon, qisqa manzil).
3. Bitta HAQIQIY test buyurtma yuborib, bazada paydo bo'lganini tekshir. Shuni bil: bu buyurtma oshxona printeriga chek chiqarishi va admin/oshpaz/kuryerga bildirishnoma yuborishi mumkin. Test ismini aniq "TEST — o'chiriladi" deb yoz. Keyin test buyurtmani, unga bog'liq kitchen_tickets yozuvlarini va bildirishnomalarni o'chir, ombor qoldig'ini tikla, so'ng `PRAGMA integrity_check` ishlat.
4. QR-menyu (`table-menu.html`) va bosh sahifa (`index.html`) avvalgidek ishlashini tekshir.

## Yakunda
- OXIRGI-ISH.md ga yangi yozuv qo'sh: nima o'zgardi, qaysi fayllar, qanday tekshirildi, zaxira nusxalar qayerda.
- Menga qisqa hisobot ber va qaytarish (rollback) buyrug'ini yoz: `.bak` fayllarni joyiga qaytarish.
- Biror narsa noaniq bo'lsa yoki backend'ni o'zgartirish kerak bo'lib qolsa, TO'XTA va mendan so'ra.
