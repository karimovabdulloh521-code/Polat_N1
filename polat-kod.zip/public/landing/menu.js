// Ziyo Famliy — mijozlar uchun menyu + savat (qayta dizayn, 2026-10-15).
// Mustaqil modul — script.js'dagi header/nav/"Stol bron qilish" kodiga
// tegmaydi, faqat #menu bo'limi + savat + checkout + taom oynasi shu yerda.
(function () {
  'use strict';

  const LS_KEY = 'zf-cart';

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function fmtSom(n) {
    return Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm";
  }
  // Apostrof variantlari (o'/oʻ/o') farqisiz qidiruv — public/waiter/order.js'dagi
  // bilan bir xil naqsh.
  function normalizeSearch(s) {
    return String(s || '').toLowerCase().replace(/[ʻʼ'’`]/g, '');
  }
  function itemMatchesSearch(it, q) {
    if (normalizeSearch(it.name).includes(q)) return true;
    return (it.variants || []).some((v) => normalizeSearch(v.name).includes(q));
  }

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    const menuRoot = document.querySelector('#menu .zfm-root');
    if (!menuRoot) return;

    // ---- DOM ----
    const toolbarEl = document.getElementById('zfmToolbar');
    const searchInput = document.getElementById('zfmSearchInput');
    const catsEl = document.getElementById('zfmCats');
    const mainEl = document.getElementById('zfmMain');

    const cartFab = document.getElementById('zfmCartFab');
    const cartFabLabel = document.getElementById('zfmCartFabLabel');

    const cartSheetBackdrop = document.getElementById('zfmCartSheetBackdrop');
    const cartSheetEl = cartSheetBackdrop.querySelector('.zfm-sheet');
    const cartSheetClose = document.getElementById('zfmCartSheetClose');
    const cartSheetBody = document.getElementById('zfmCartSheetBody');
    const cartSheetFooter = document.getElementById('zfmCartSheetFooter');

    const cartPanelBody = document.getElementById('zfmCartPanelBody');
    const cartPanelFooter = document.getElementById('zfmCartPanelFooter');

    const itemBackdrop = document.getElementById('zfmItemBackdrop');
    const itemSheet = document.getElementById('zfmItemSheet');
    const itemImgWrap = document.getElementById('zfmItemImgWrap');
    const itemClose = document.getElementById('zfmItemClose');
    const itemNameEl = document.getElementById('zfmItemName');
    const itemVolumeEl = document.getElementById('zfmItemVolume');
    const itemDescEl = document.getElementById('zfmItemDesc');
    const variantListEl = document.getElementById('zfmVariantList');
    const itemQtyValEl = document.getElementById('zfmItemQtyVal');
    const itemQtyDecBtn = document.getElementById('zfmItemQtyDec');
    const itemQtyIncBtn = document.getElementById('zfmItemQtyInc');
    const itemAddBtn = document.getElementById('zfmItemAddBtn');

    const checkoutBackdrop = document.getElementById('zfmCheckoutBackdrop');
    const checkoutSheet = document.getElementById('zfmCheckoutSheet');
    const checkoutClose = document.getElementById('zfmCheckoutClose');
    const checkoutFormWrap = document.getElementById('zfmCheckoutFormWrap');
    const checkoutForm = document.getElementById('zfmCheckoutForm');
    const checkoutSuccessEl = document.getElementById('zfmCheckoutSuccess');
    const successText = document.getElementById('zfmSuccessText');
    const successCloseBtn = document.getElementById('zfmSuccessClose');
    const checkoutSummaryEl = document.getElementById('zfmCheckoutSummary');
    const formErrorEl = document.getElementById('zfmFormError');
    const submitBtn = document.getElementById('zfmSubmitBtn');

    const nameInput = document.getElementById('zfmName');
    const nameField = document.getElementById('zfmNameField');
    const nameErrorEl = document.getElementById('zfmNameError');
    const phoneInput = document.getElementById('zfmPhone');
    const phoneWrap = document.getElementById('zfmPhoneWrap');
    const phoneErrorEl = document.getElementById('zfmPhoneError');
    const segmentEl = document.getElementById('zfmFulfillmentSegment');
    const addressField = document.getElementById('zfmAddressField');
    const addressInput = document.getElementById('zfmAddress');
    const addressErrorEl = document.getElementById('zfmAddressError');
    const locationBtn = document.getElementById('zfmLocationBtn');
    const locationStatusEl = document.getElementById('zfmLocationStatus');
    const noteInput = document.getElementById('zfmNote');
    const honeypotInput = document.getElementById('zfmWebsite');

    const toastWrap = document.getElementById('zfmToastWrap');

    // ---- Holat ----
    let categories = [];
    const itemsById = new Map(); // id -> { ...item, categoryId, parentId?, parentName? }
    const cart = new Map(); // id -> qty
    const cartFlags = new Map(); // id -> 'unavailable' (409 javobidan keyin)
    let activeCatId = null;
    let searchQuery = '';
    let currentFulfillment = 'pickup';
    let capturedLocation = null;
    let currentModalItem = null;
    let modalQty = 1;
    let modalSelectedId = null;

    // Fokus boshqarish uchun oddiy overlay-stek: Esc/Tab shu orqali ishlaydi.
    const overlayStack = [];
    function focusables(container) {
      return Array.from(container.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))
        .filter((el) => !el.disabled && el.offsetParent !== null);
    }
    function openOverlay(backdropEl, sheetEl) {
      const returnFocus = document.activeElement;
      backdropEl.classList.add('open');
      document.body.style.overflow = 'hidden';
      const entry = { backdropEl, sheetEl, returnFocus, close: null };
      entry.close = function close() {
        backdropEl.classList.remove('open');
        const idx = overlayStack.indexOf(entry);
        if (idx !== -1) overlayStack.splice(idx, 1);
        if (overlayStack.length === 0) document.body.style.overflow = '';
        if (returnFocus && document.contains(returnFocus)) returnFocus.focus();
      };
      overlayStack.push(entry);
      const f = focusables(sheetEl);
      if (f.length) f[0].focus();
      return entry.close;
    }
    document.addEventListener('keydown', (e) => {
      if (overlayStack.length === 0) return;
      const top = overlayStack[overlayStack.length - 1];
      if (e.key === 'Escape') { e.preventDefault(); top.close(); return; }
      if (e.key === 'Tab') {
        const f = focusables(top.sheetEl);
        if (f.length === 0) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    [itemBackdrop, checkoutBackdrop, cartSheetBackdrop].forEach((bd) => {
      bd.addEventListener('click', (e) => {
        if (e.target !== bd) return;
        const entry = overlayStack.find((o) => o.backdropEl === bd);
        if (entry) entry.close();
      });
    });

    // ---- Toast ----
    function showToast(message) {
      const el = document.createElement('div');
      el.className = 'zfm-toast';
      el.textContent = message;
      toastWrap.appendChild(el);
      requestAnimationFrame(() => el.classList.add('show'));
      setTimeout(() => {
        el.classList.remove('show');
        setTimeout(() => el.remove(), 250);
      }, 2600);
    }

    // ---- Savat: localStorage ----
    function loadCartRaw() {
      try {
        const raw = JSON.parse(localStorage.getItem(LS_KEY) || '{}');
        if (raw && typeof raw === 'object') return raw;
      } catch (e) { /* buzilgan qiymat — e'tiborsiz */ }
      return {};
    }
    function saveCart() {
      try {
        const plain = {};
        cart.forEach((qty, id) => { plain[id] = qty; });
        localStorage.setItem(LS_KEY, JSON.stringify(plain));
      } catch (e) { /* localStorage yo'q/to'lgan — savat shu sessiyada baribir ishlayveradi */ }
    }

    // ---- Menyuni yuklash ----
    function renderSkeleton() {
      let html = '';
      for (let i = 0; i < 6; i++) {
        html += `<div class="zfm-skeleton-card"><div class="zfm-sk-img"></div><div class="zfm-sk-line w60"></div><div class="zfm-sk-line w40"></div></div>`;
      }
      mainEl.innerHTML = `<div class="zfm-section"><div class="zfm-grid">${html}</div></div>`;
    }
    function renderLoadError() {
      mainEl.innerHTML = `<div class="zfm-load-error"><p>Menyuni yuklab bo'lmadi.</p><button type="button" id="zfmRetryBtn">Qayta urinish</button></div>`;
      document.getElementById('zfmRetryBtn').addEventListener('click', fetchMenu);
    }

    function fetchMenu() {
      renderSkeleton();
      fetch('../api/public/menu')
        .then((res) => {
          if (!res.ok) throw new Error('bad status');
          return res.json();
        })
        .then((data) => {
          categories = Array.isArray(data.categories) ? data.categories : [];
          buildItemsIndex();
          reconcileCart();
          renderCats();
          renderSections();
          updateCartUI();
        })
        .catch(() => renderLoadError());
    }

    function buildItemsIndex() {
      itemsById.clear();
      categories.forEach((cat) => {
        cat.items.forEach((it) => {
          itemsById.set(it.id, { ...it, categoryId: cat.id });
          (it.variants || []).forEach((v) => {
            itemsById.set(v.id, { ...v, categoryId: cat.id, parentId: it.id, parentName: it.name });
          });
        });
      });
    }

    // Savatdagi (localStorage'dan kelgan) bandlarni yangi menyu bilan
    // solishtiradi — o'chirilgan/tugagan band savatdan olib tashlanadi,
    // narxi esa har doim itemsById'dan (joriy) o'qilgani uchun avtomatik yangi.
    function reconcileCart() {
      cart.clear();
      cartFlags.clear();
      const raw = loadCartRaw();
      let removed = 0;
      Object.keys(raw).forEach((key) => {
        const id = Number(key);
        const qty = Math.max(0, Math.min(50, Math.round(Number(raw[key]) || 0)));
        const item = itemsById.get(id);
        if (!item || !item.available || qty <= 0) { removed += 1; return; }
        cart.set(id, qty);
      });
      if (removed > 0) {
        saveCart();
        showToast(removed === 1 ? "Savatdagi 1 ta taom endi mavjud emas, olib tashlandi" : `Savatdagi ${removed} ta taom endi mavjud emas, olib tashlandi`);
      }
    }

    // ---- Toolbar balandligi (scroll-padding uchun) ----
    function measureToolbar() {
      menuRoot.style.setProperty('--zfm-toolbar-h', toolbarEl.offsetHeight + 'px');
    }
    measureToolbar();
    if (window.ResizeObserver) {
      new ResizeObserver(measureToolbar).observe(toolbarEl);
    } else {
      window.addEventListener('resize', measureToolbar);
    }

    // ---- Kategoriya pill'lari ----
    function renderCats() {
      catsEl.innerHTML = categories.map((cat) => `
        <button type="button" class="zfm-cat-btn${cat.id === activeCatId ? ' active' : ''}" data-cat="${cat.id}" role="tab" aria-selected="${cat.id === activeCatId}">${escapeHtml(cat.name)}</button>
      `).join('');
      catsEl.querySelectorAll('[data-cat]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const catId = Number(btn.dataset.cat);
          if (searchQuery) {
            searchInput.value = '';
            searchQuery = '';
          }
          activeCatId = catId;
          renderCats();
          renderSections();
          btn.scrollIntoView({ block: 'nearest', inline: 'center' });
          const target = document.getElementById(`zfm-sec-${catId}`);
          if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      });
    }

    // ---- Taom kartochkasi ----
    function cardImageHtml(it, cls) {
      if (it.image) return `<div class="${cls}"><img src="${escapeHtml(it.image)}" alt="${escapeHtml(it.name)}" loading="lazy" decoding="async"></div>`;
      const letter = (it.name || '?').trim().charAt(0).toUpperCase() || '?';
      return `<div class="${cls} no-image"><span>${escapeHtml(letter)}</span></div>`;
    }

    function itemOptions(it) {
      const variants = it.variants || [];
      return variants.length > 0 ? [{ id: it.id, name: it.name, price: it.price, available: it.available }, ...variants] : [it];
    }

    function cardActionsHtml(it) {
      const hasVariants = (it.variants || []).length > 0;
      if (hasVariants) {
        const options = itemOptions(it);
        const anyAvailable = options.some((o) => o.available);
        return `<button type="button" class="zfm-add-btn" data-open-item="${it.id}" ${anyAvailable ? '' : 'disabled'}>+ Tanlash</button>`;
      }
      if (!it.available) {
        return `<button type="button" class="zfm-add-btn" disabled>Tugagan</button>`;
      }
      const qty = cart.get(it.id) || 0;
      if (qty > 0) {
        return `
          <div class="zfm-qty-stepper" data-stepper="${it.id}">
            <button type="button" data-dec="${it.id}" aria-label="Kamaytirish">&minus;</button>
            <span class="val">${qty}</span>
            <button type="button" data-inc="${it.id}" aria-label="Oshirish">+</button>
          </div>
        `;
      }
      return `<button type="button" class="zfm-add-btn" data-add="${it.id}">+ Savatga</button>`;
    }

    function cardHtml(it) {
      const hasVariants = (it.variants || []).length > 0;
      const options = hasVariants ? itemOptions(it) : [it];
      const availableOptions = options.filter((o) => o.available);
      const priceBasis = availableOptions.length ? availableOptions : options;
      const minPrice = Math.min(...priceBasis.map((o) => o.price));
      const cardAvailable = hasVariants ? options.some((o) => o.available) : it.available;

      return `
        <div class="zfm-card${cardAvailable ? '' : ' is-unavailable'}" data-item-card="${it.id}">
          <div class="zfm-card-img-outer" style="position:relative;">
            ${cardImageHtml(it, 'zfm-card-img')}
            ${hasVariants ? `<span class="zfm-card-tag">${options.length} xil</span>` : ''}
            ${!cardAvailable ? `<span class="zfm-card-unavailable-tag">Tugagan</span>` : ''}
          </div>
          <div class="zfm-card-body">
            <h3 class="zfm-card-name">${escapeHtml(it.name)}${it.volume ? ` <span class="zfm-card-volume">(${escapeHtml(it.volume)})</span>` : ''}</h3>
            ${it.description ? `<p class="zfm-card-desc">${escapeHtml(it.description)}</p>` : ''}
            <div class="zfm-card-price">${hasVariants ? `<span class="from">dan</span> ` : ''}${fmtSom(minPrice)}</div>
          </div>
          <div class="zfm-card-actions" data-card-actions="${it.id}">${cardActionsHtml(it)}</div>
        </div>
      `;
    }

    function syncCardActions(id) {
      const el = mainEl.querySelector(`[data-card-actions="${id}"]`);
      const item = itemsById.get(id);
      if (!el || !item) return;
      el.innerHTML = cardActionsHtml(item);
    }

    // Delegatsiya orqali BITTA marta ulanadi (init()da) — syncCardActions()
    // taom kartochkasining faqat harakat qismini (innerHTML) almashtirganda
    // ham ishlayveradi, chunki tinglovchi mainEl'ning o'zida turadi, har safar
    // qayta ulash shart emas (avval har render'da qayta ulanardi — shu sabab
    // "+Savatga" bosilgach paydo bo'ladigan −/+ stepper endi ishlamay qolgan
    // edi, Playwright bilan sinalganda topilgan haqiqiy bug).
    function setupGridDelegation(container) {
      container.addEventListener('click', (e) => {
        const addBtn = e.target.closest('[data-add]');
        if (addBtn) {
          const id = Number(addBtn.dataset.add);
          addToCart(id, 1);
          const item = itemsById.get(id);
          showToast(`${item.name} savatga qo'shildi`);
          syncCardActions(id);
          updateCartUI();
          return;
        }
        const incBtn = e.target.closest('[data-inc]');
        if (incBtn) {
          const id = Number(incBtn.dataset.inc);
          addToCart(id, 1);
          syncCardActions(id);
          updateCartUI();
          return;
        }
        const decBtn = e.target.closest('[data-dec]');
        if (decBtn) {
          const id = Number(decBtn.dataset.dec);
          addToCart(id, -1);
          syncCardActions(id);
          updateCartUI();
          return;
        }
        const openBtn = e.target.closest('[data-open-item]');
        if (openBtn) openItemModal(Number(openBtn.dataset.openItem));
      });
    }

    function addToCart(id, delta) {
      const current = cart.get(id) || 0;
      const next = Math.max(0, Math.min(50, current + delta));
      if (next === 0) cart.delete(id); else cart.set(id, next);
      cartFlags.delete(id);
      saveCart();
    }
    function setQty(id, qty) {
      const next = Math.max(0, Math.min(50, Math.round(qty)));
      if (next === 0) { cart.delete(id); cartFlags.delete(id); } else cart.set(id, next);
      saveCart();
    }

    // ---- Bo'limlar (sections) / qidiruv natijalari ----
    function renderSections() {
      const q = normalizeSearch(searchQuery);

      if (q) {
        const matched = [];
        categories.forEach((cat) => cat.items.forEach((it) => { if (itemMatchesSearch(it, q)) matched.push(it); }));
        mainEl.innerHTML = `
          <div class="zfm-section">
            <div class="zfm-section-head"><h2>Qidiruv</h2><span class="zfm-section-count">${matched.length} ta</span></div>
            ${matched.length === 0
              ? `<p class="zfm-empty">&ldquo;${escapeHtml(searchQuery)}&rdquo; bo'yicha hech narsa topilmadi</p>`
              : `<div class="zfm-grid">${matched.map(cardHtml).join('')}</div>`}
          </div>
        `;
        return;
      }

      if (categories.length === 0) {
        mainEl.innerHTML = `<p class="zfm-empty">Hozircha menyu qo'shilmagan.</p>`;
        return;
      }

      if (!activeCatId || !categories.some((c) => c.id === activeCatId)) {
        activeCatId = categories[0].id;
        renderCats();
      }

      const cat = categories.find((c) => c.id === activeCatId);
      mainEl.innerHTML = `
        <section class="zfm-section" id="zfm-sec-${cat.id}" data-cat="${cat.id}">
          <div class="zfm-section-head"><h2>${escapeHtml(cat.name)}</h2><span class="zfm-section-count">${cat.items.length} ta</span></div>
          <div class="zfm-grid">${cat.items.map(cardHtml).join('')}</div>
        </section>
      `;
    }

    let searchDebounce = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(() => {
        searchQuery = searchInput.value.trim();
        renderSections();
      }, 120);
    });

    // ---- Taom oynasi (variantlar) ----
    function renderVariantList() {
      const options = itemOptions(currentModalItem);
      variantListEl.innerHTML = options.map((o) => `
        <button type="button" class="zfm-variant-opt${o.id === modalSelectedId ? ' selected' : ''}" data-variant="${o.id}" ${o.available ? '' : 'disabled'}>
          <span class="name">${escapeHtml(o.name)}${o.available ? '' : ' (tugagan)'}</span>
          <span class="price">${fmtSom(o.price)}</span>
        </button>
      `).join('');
      variantListEl.querySelectorAll('[data-variant]').forEach((btn) => {
        btn.addEventListener('click', () => {
          modalSelectedId = Number(btn.dataset.variant);
          renderVariantList();
          updateItemModalFooter();
        });
      });
    }

    function updateItemModalFooter() {
      itemQtyValEl.textContent = String(modalQty);
      const selected = modalSelectedId ? itemsById.get(modalSelectedId) || itemOptions(currentModalItem).find((o) => o.id === modalSelectedId) : null;
      if (selected) {
        itemAddBtn.disabled = false;
        itemAddBtn.textContent = `Savatga · ${fmtSom(selected.price * modalQty)}`;
      } else {
        itemAddBtn.disabled = true;
        itemAddBtn.textContent = 'Savatga';
      }
    }

    function openItemModal(itemId) {
      const it = itemsById.get(itemId);
      if (!it) return;
      currentModalItem = it;
      modalQty = 1;
      const options = itemOptions(it);
      const firstAvailable = options.find((o) => o.available);
      modalSelectedId = firstAvailable ? firstAvailable.id : null;

      itemImgWrap.innerHTML = '';
      itemImgWrap.appendChild(itemClose);
      if (it.image) {
        const img = document.createElement('img');
        img.src = it.image; img.alt = it.name; img.loading = 'lazy';
        itemImgWrap.classList.remove('no-image');
        itemImgWrap.appendChild(img);
      } else {
        itemImgWrap.classList.add('no-image');
        const span = document.createElement('span');
        span.textContent = (it.name || '?').trim().charAt(0).toUpperCase() || '?';
        itemImgWrap.appendChild(span);
      }
      itemNameEl.textContent = it.name;
      itemVolumeEl.textContent = it.volume || '';
      itemVolumeEl.style.display = it.volume ? '' : 'none';
      itemDescEl.textContent = it.description || '';
      itemDescEl.style.display = it.description ? '' : 'none';
      renderVariantList();
      updateItemModalFooter();

      openOverlay(itemBackdrop, itemSheet);
    }
    function closeItemModalEl() {
      const entry = overlayStack.find((o) => o.backdropEl === itemBackdrop);
      if (entry) entry.close();
    }
    itemClose.addEventListener('click', closeItemModalEl);
    itemQtyDecBtn.addEventListener('click', () => { modalQty = Math.max(1, modalQty - 1); updateItemModalFooter(); });
    itemQtyIncBtn.addEventListener('click', () => { modalQty = Math.min(50, modalQty + 1); updateItemModalFooter(); });
    itemAddBtn.addEventListener('click', () => {
      if (!modalSelectedId) return;
      addToCart(modalSelectedId, modalQty);
      const selected = itemsById.get(modalSelectedId);
      showToast(`${selected.name} savatga qo'shildi`);
      updateCartUI();
      closeItemModalEl();
    });

    // ---- Savat render (sheet + panel umumiy) ----
    function cartEntries() {
      const list = [];
      cart.forEach((qty, id) => {
        const item = itemsById.get(id);
        if (!item) return;
        list.push({ id, item, qty, flagged: cartFlags.get(id) === 'unavailable' });
      });
      return list;
    }
    function cartPurchasableEntries() {
      return cartEntries().filter((e) => !e.flagged);
    }
    function cartTotal() {
      return cartPurchasableEntries().reduce((sum, e) => sum + e.qty * e.item.price, 0);
    }
    function cartCount() {
      return cartPurchasableEntries().reduce((sum, e) => sum + e.qty, 0);
    }

    function cartRowHtml(entry) {
      const { id, item, qty, flagged } = entry;
      const sub = item.parentId
        ? `${escapeHtml(item.name)} · ${fmtSom(item.price)}`
        : (item.volume ? `${escapeHtml(item.volume)} · ${fmtSom(item.price)}` : fmtSom(item.price));
      const title = item.parentId ? item.parentName : item.name;
      return `
        <div class="zfm-cart-row" data-cart-row="${id}">
          ${item.image ? `<img class="zfm-cart-row-img" src="${escapeHtml(item.image)}" alt="">` : `<div class="zfm-cart-row-img no-image">${escapeHtml((title || '?').charAt(0).toUpperCase())}</div>`}
          <div class="zfm-cart-row-main">
            <p class="zfm-cart-row-name">${escapeHtml(title)}${flagged ? ' <span style="color:var(--danger);font-weight:700;">(tugagan)</span>' : ''}</p>
            <p class="zfm-cart-row-sub">${sub}</p>
          </div>
          <div class="zfm-cart-row-right">
            <span class="zfm-cart-row-sum">${flagged ? '' : fmtSom(qty * item.price)}</span>
            ${flagged
              ? `<button type="button" class="zfm-location-btn" data-cart-remove="${id}" style="padding:4px 10px;font-size:12px;">Olib tashlash</button>`
              : `<div class="zfm-cart-row-stepper"><button type="button" data-cart-dec="${id}" aria-label="Kamaytirish">&minus;</button><span>${qty}</span><button type="button" data-cart-inc="${id}" aria-label="Oshirish">+</button></div>`}
          </div>
        </div>
      `;
    }

    function renderCartInto(bodyEl, footerEl, { checkoutBtnId }) {
      const entries = cartEntries();
      if (entries.length === 0) {
        bodyEl.innerHTML = `<p class="zfm-cart-empty">Savat bo'sh — menyudan yoqqan taomingizni tanlang</p>`;
        footerEl.innerHTML = '';
        return;
      }
      bodyEl.innerHTML = `<div class="zfm-cart-list">${entries.map(cartRowHtml).join('')}</div>`;
      const total = cartTotal();
      footerEl.innerHTML = `
        <div class="zfm-cart-total-row"><span>Jami</span><span>${fmtSom(total)}</span></div>
        <p class="zfm-cart-note">Yetkazib berish narxini operator aytadi</p>
        <button type="button" class="zfm-cart-checkout-btn" id="${checkoutBtnId}" ${cartPurchasableEntries().length === 0 ? 'disabled' : ''}>Rasmiylashtirish</button>
      `;
      bodyEl.querySelectorAll('[data-cart-inc]').forEach((b) => b.addEventListener('click', () => { addToCart(Number(b.dataset.cartInc), 1); syncCardActions(Number(b.dataset.cartInc)); updateCartUI(); }));
      bodyEl.querySelectorAll('[data-cart-dec]').forEach((b) => b.addEventListener('click', () => { addToCart(Number(b.dataset.cartDec), -1); syncCardActions(Number(b.dataset.cartDec)); updateCartUI(); }));
      bodyEl.querySelectorAll('[data-cart-remove]').forEach((b) => b.addEventListener('click', () => { setQty(Number(b.dataset.cartRemove), 0); cartFlags.delete(Number(b.dataset.cartRemove)); updateCartUI(); }));
      const btn = document.getElementById(checkoutBtnId);
      if (btn) btn.addEventListener('click', openCheckout);
    }

    function updateCartUI() {
      const count = cartCount();
      const total = cartTotal();
      cartFabLabel.textContent = `${count} · Savat · ${fmtSom(total)}`;
      cartFab.classList.toggle('show', count > 0 || cartEntries().some((e) => e.flagged));
      renderCartInto(cartSheetBody, cartSheetFooter, { checkoutBtnId: 'zfmCheckoutBtnSheet' });
      renderCartInto(cartPanelBody, cartPanelFooter, { checkoutBtnId: 'zfmCheckoutBtnPanel' });
    }

    cartFab.addEventListener('click', () => openOverlay(cartSheetBackdrop, cartSheetEl));
    cartSheetClose.addEventListener('click', () => {
      const entry = overlayStack.find((o) => o.backdropEl === cartSheetBackdrop);
      if (entry) entry.close();
    });

    // ---- Checkout ----
    function fieldError(fieldEl, errorEl, message) {
      if (message) {
        fieldEl.classList.add('has-error');
        errorEl.textContent = message;
      } else {
        fieldEl.classList.remove('has-error');
        errorEl.textContent = '';
      }
    }
    function clearFormErrors() {
      fieldError(nameField, nameErrorEl, '');
      fieldError(phoneWrap, phoneErrorEl, '');
      fieldError(addressField, addressErrorEl, '');
      formErrorEl.textContent = '';
    }

    function renderCheckoutSummary() {
      const entries = cartPurchasableEntries();
      const total = entries.reduce((sum, e) => sum + e.qty * e.item.price, 0);
      checkoutSummaryEl.innerHTML = entries
        .map((e) => `<div class="zfm-checkout-summary-row"><span>${escapeHtml(e.item.parentId ? e.item.parentName + ' — ' + e.item.name : e.item.name)} &times; ${e.qty}</span><span>${fmtSom(e.qty * e.item.price)}</span></div>`)
        .join('') + `
        <div class="zfm-checkout-summary-row"><span>Yetkazib berish</span><span>Operator aytadi</span></div>
        <div class="zfm-checkout-summary-total"><span>Jami</span><span>${fmtSom(total)}</span></div>
      `;
    }

    function openCheckout() {
      if (cartPurchasableEntries().length === 0) return;
      clearFormErrors();
      renderCheckoutSummary();
      checkoutFormWrap.classList.remove('hidden');
      checkoutSuccessEl.classList.add('hidden');
      openOverlay(checkoutBackdrop, checkoutSheet);
    }
    function closeCheckoutEl() {
      const entry = overlayStack.find((o) => o.backdropEl === checkoutBackdrop);
      if (entry) entry.close();
    }
    checkoutClose.addEventListener('click', closeCheckoutEl);
    successCloseBtn.addEventListener('click', closeCheckoutEl);

    segmentEl.querySelectorAll('button').forEach((btn) => {
      btn.addEventListener('click', () => {
        currentFulfillment = btn.dataset.fulfillment;
        segmentEl.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b === btn));
        addressField.classList.toggle('hidden', currentFulfillment !== 'delivery');
      });
    });

    // Telefon — foydalanuvchi faqat 9 ta raqam kiritadi, "+998" doim ko'rinadi.
    phoneInput.addEventListener('input', () => {
      const digits = phoneInput.value.replace(/\D/g, '').slice(0, 9);
      const groups = [digits.slice(0, 2), digits.slice(2, 5), digits.slice(5, 7), digits.slice(7, 9)].filter(Boolean);
      phoneInput.value = groups.join(' ');
    });

    locationBtn.addEventListener('click', () => {
      if (!navigator.geolocation) {
        locationStatusEl.textContent = "Qurilma joylashuvni aniqlay olmaydi, manzilni qo'lda yozing";
        locationStatusEl.className = 'zfm-location-status';
        return;
      }
      locationBtn.disabled = true;
      locationStatusEl.textContent = 'Joylashuv so\'ralmoqda...';
      locationStatusEl.className = 'zfm-location-status';
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          capturedLocation = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          locationStatusEl.textContent = "Joylashuv qo'shildi ✓";
          locationStatusEl.className = 'zfm-location-status ok';
          locationBtn.disabled = false;
        },
        () => {
          capturedLocation = null;
          locationStatusEl.textContent = "Joylashuvni aniqlab bo'lmadi, manzilni qo'lda yozing";
          locationStatusEl.className = 'zfm-location-status';
          locationBtn.disabled = false;
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    });

    function resetCheckoutForm() {
      checkoutForm.reset();
      currentFulfillment = 'pickup';
      segmentEl.querySelectorAll('button').forEach((b, i) => b.classList.toggle('active', i === 0));
      addressField.classList.add('hidden');
      capturedLocation = null;
      locationStatusEl.textContent = '';
      locationStatusEl.className = 'zfm-location-status';
      clearFormErrors();
    }

    checkoutForm.addEventListener('submit', (e) => {
      e.preventDefault();
      clearFormErrors();

      const entries = cartPurchasableEntries();
      if (entries.length === 0) { formErrorEl.textContent = "Savat bo'sh"; return; }

      const fullName = nameInput.value.trim();
      const phoneDigits = phoneInput.value.replace(/\D/g, '');
      const addressText = addressInput.value.trim();

      let firstInvalid = null;
      if (fullName.length < 2 || fullName.length > 60) {
        fieldError(nameField, nameErrorEl, 'Ismingizni to\'liq kiriting (2–60 belgi)');
        firstInvalid = firstInvalid || nameInput;
      }
      if (phoneDigits.length !== 9) {
        fieldError(phoneWrap, phoneErrorEl, 'Raqamni to\'liq kiriting: 9 ta raqam');
        firstInvalid = firstInvalid || phoneInput;
      }
      if (currentFulfillment === 'delivery' && (addressText.length < 5 || addressText.length > 200)) {
        fieldError(addressField, addressErrorEl, 'Manzilni to\'liq kiriting (5–200 belgi)');
        firstInvalid = firstInvalid || addressInput;
      }
      if (firstInvalid) { firstInvalid.focus(); return; }

      const payload = {
        full_name: fullName,
        phone: phoneDigits,
        fulfillment: currentFulfillment,
        address: addressText,
        note: noteInput.value.trim(),
        items: entries.map((e) => ({ menu_item_id: e.id, quantity: e.qty })),
        idempotency_key: crypto.randomUUID(),
        website: honeypotInput.value,
      };
      if (currentFulfillment === 'delivery' && capturedLocation) {
        payload.location_lat = capturedLocation.lat;
        payload.location_lng = capturedLocation.lng;
      }

      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="zfm-spinner"></span> Yuborilmoqda...';

      fetch('../api/public/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
        .then(async (res) => {
          const data = await res.json().catch(() => ({}));
          if (res.status === 409 && Array.isArray(data.unavailable_items)) {
            data.unavailable_items.forEach((u) => { cartFlags.set(u.menu_item_id, 'unavailable'); });
            updateCartUI();
            closeCheckoutEl();
            showToast(data.error || 'Savatdagi bir nechta taom tugagan');
            return;
          }
          if (res.status === 429) {
            formErrorEl.textContent = data.error || "Juda ko'p urinish, birozdan so'ng qayta urinib ko'ring";
            return;
          }
          if (!res.ok) {
            if (data.field === 'full_name') fieldError(nameField, nameErrorEl, data.error);
            else if (data.field === 'phone') fieldError(phoneWrap, phoneErrorEl, data.error);
            else if (data.field === 'address') fieldError(addressField, addressErrorEl, data.error);
            else formErrorEl.textContent = data.error || "Xatolik yuz berdi, birozdan so'ng qayta urinib ko'ring";
            return;
          }

          successText.textContent = currentFulfillment === 'delivery'
            ? "Operator tez orada qo'ng'iroq qilib, manzil va yetkazib berish narxini tasdiqlaydi."
            : "Operator qo'ng'iroq qilib, buyurtma qachon tayyor bo'lishini aytadi.";
          successText.textContent += ` Buyurtma № ${data.id}.`;
          checkoutFormWrap.classList.add('hidden');
          checkoutSuccessEl.classList.remove('hidden');
          cart.clear();
          cartFlags.clear();
          saveCart();
          updateCartUI();
          renderSections();
          resetCheckoutForm();
        })
        .catch(() => {
          formErrorEl.textContent = "Internet aloqasi yo'q, birozdan so'ng qayta urinib ko'ring";
        })
        .finally(() => {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Buyurtma berish';
        });
    });

    // ---- Boshlash ----
    setupGridDelegation(mainEl);
    fetchMenu();
  }
})();
