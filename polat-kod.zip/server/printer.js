const { WebSocketServer } = require('ws');

function setupKitchenPrinter(server, db, token) {
  if (!token) throw new Error('PRINT_TOKEN berilmagan');

  db.exec(`CREATE TABLE IF NOT EXISTS print_jobs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    payload    TEXT    NOT NULL,
    printed    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  )`);

  const insertJob   = db.prepare('INSERT INTO print_jobs (payload) VALUES (?)');
  const pendingJobs = db.prepare('SELECT id, payload FROM print_jobs WHERE printed = 0 ORDER BY id');
  const markPrinted = db.prepare('UPDATE print_jobs SET printed = 1 WHERE id = ?');

  const wss = new WebSocketServer({ server, path: '/print-agent' });
  let agent = null;

  const sendJob = (ws, id, order) =>
    ws.send(JSON.stringify({ type: 'job', id, order }));

  wss.on('connection', (ws, req) => {
    if (req.headers.authorization !== `Bearer ${token}`) {
      return ws.close(1008, 'Ruxsat yo\'q');
    }
    if (agent) agent.terminate();
    agent = ws;
    ws.isAlive = true;
    console.log('Oshxona agenti ulandi');

    for (const job of pendingJobs.all()) {
      sendJob(ws, job.id, JSON.parse(job.payload));
    }

    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw);
        if (msg.type === 'printed') markPrinted.run(msg.id);
      } catch {}
    });
    ws.on('close', () => {
      if (agent === ws) agent = null;
      console.log('Oshxona agenti uzildi');
    });
  });

  const timer = setInterval(() => {
    if (!agent) return;
    if (!agent.isAlive) return agent.terminate();
    agent.isAlive = false;
    agent.ping();
  }, 20000);
  wss.on('close', () => clearInterval(timer));

  function printOrder(order) {
    const { lastInsertRowid } = insertJob.run(JSON.stringify(order));
    const id = Number(lastInsertRowid);
    if (agent && agent.readyState === agent.OPEN) sendJob(agent, id, order);
    return id;
  }

  return { printOrder, isAgentOnline: () => agent !== null };
}

module.exports = { setupKitchenPrinter };
